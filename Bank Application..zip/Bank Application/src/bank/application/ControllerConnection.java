package bank.application;
import java.sql.*;

public class ControllerConnection {
    private Connection connect;
    private Statement statement;

    // Constructor to establish the connection
    public ControllerConnection() {
        try {
            // Load MySQL JDBC driver (Optional in newer versions of Java)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // Establish the connection to the database
            connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankModel", "root", "Kartik@1234");
            
            // Create a Statement object to interact with the database
            statement = connect.createStatement();
        } catch (SQLException | ClassNotFoundException e) {
            // Proper error logging
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to retrieve the connection object
    public Connection getConnection() {
        return connect;
    }

    // Method to close resources (good practice)
    public void closeConnection() {
        try {
            if (statement != null && !statement.isClosed()) {
                statement.close();
            }
            if (connect != null && !connect.isClosed()) {
                connect.close();
            }
        } catch (SQLException e) {
            System.out.println("Error closing connection: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
