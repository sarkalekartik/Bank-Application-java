package bank.application;

import java.sql.*;

public class Conn {
    
    
    

    public static void main(String arg[])
     {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
 
           
                   
                   
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://Mysql@localhost:3306/ bankmodel", "root", "Kartik@1234");
            
                    Statement statement;
            statement = connection.createStatement();
            ResultSet resultSet;
            resultSet = statement.executeQuery(
                "select * from Branches");
           
            String BranchName;
            while (resultSet.next()) {
            
               BranchName = resultSet.getString("BranchName").trim();
                System.out.println("BranchName : " + BranchName
                             );
            }
            resultSet.close();
            statement.close();
            connection.close();
            
        } catch (ClassNotFoundException | SQLException e) {
        }
    }
}